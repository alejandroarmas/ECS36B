//
// gcdistance.h
//
#ifndef GCDISTANCE_H
#define GCDISTANCE_H
double gcdistance(double lat1, double lon1, double lat2, double lon2);
#endif
